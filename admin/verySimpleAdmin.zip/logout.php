<?php
session_start();
include_once'../config/setting.php';
session_destroy();
header('location:'.BASE_URL.'/admin');
?>