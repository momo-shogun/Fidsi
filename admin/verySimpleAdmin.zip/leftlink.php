<div class="col-lg-3">
    <div class="list-group">
        <a href="dashboard.php" role="button" class="list-group-item list-group-item-action">Dashbaord</a>
        <a href="contact.php" role="button" class="list-group-item list-group-item-action">Contact Form</a>
    </div>
</div>